package com.xuperelbicho.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080D0B)
private val Panel = Color(0xFF142019)
private val Neon = Color(0xFFB7FF55)
private val Muted = Color(0xFFA8B6AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XuperApp() }
    }
}

data class Section(val title: String, val icon: ImageVector, val description: String)
private val sections = listOf(
    Section("TV EN VIVO", Icons.Filled.LiveTv, "Canales y programación"),
    Section("DEPORTES", Icons.Filled.SportsSoccer, "Fútbol y eventos deportivos"),
    Section("PELÍCULAS", Icons.Filled.Movie, "Cine para todos los gustos"),
    Section("SERIES", Icons.Filled.Movie, "Temporadas y episodios"),
    Section("FAVORITOS", Icons.Filled.Favorite, "Tu contenido guardado"),
    Section("BUSCAR", Icons.Filled.Search, "Encuentra lo que quieres ver"),
    Section("AJUSTES", Icons.Filled.Settings, "Preferencias de la aplicación")
)

@Composable
fun XuperApp() {
    var selected by remember { mutableStateOf("INICIO") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Neon,
            onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Row(
            modifier = Modifier.fillMaxSize().background(Ink).padding(horizontal = 42.dp, vertical = 26.dp),
            horizontalArrangement = Arrangement.spacedBy(34.dp)
        ) {
            Column(
                modifier = Modifier.width(220.dp).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("XUPER", color = Neon, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text("EL BICHO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(22.dp))
                SideItem("INICIO", selected == "INICIO", Icons.Filled.LiveTv) { selected = "INICIO" }
                sections.forEach { item ->
                    SideItem(item.title, selected == item.title, item.icon) { selected = item.title }
                }
                Spacer(Modifier.weight(1f))
                Text("VERSIÓN 0.1.0", color = Muted, fontSize = 11.sp)
            }
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("TU ENTRETENIMIENTO, A OTRO NIVEL", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(if (selected == "INICIO") "Bienvenido a XUPER" else selected, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("●  LISTO PARA EXPLORAR", color = Neon, fontSize = 12.sp)
                }
                HeroPanel()
                Text(if (selected == "INICIO") "EXPLORA XUPER" else "CONTENIDO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(sections) { item ->
                        ContentCard(item) { selected = item.title }
                    }
                }
                Text(
                    "Contenido de demostración. Agregaremos canales y catálogos autorizados en la siguiente etapa.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun SideItem(label: String, active: Boolean, icon: ImageVector, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(if (active || focused) Color(0xFF203323) else Color.Transparent, RoundedCornerShape(12.dp))
            .border(if (focused) BorderStroke(2.dp, Neon) else BorderStroke(1.dp, Color.Transparent), RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon, null, tint = if (active || focused) Neon else Muted, modifier = Modifier.size(18.dp))
        Text(label, color = if (active || focused) Color.White else Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun HeroPanel() {
    Box(
        modifier = Modifier.fillMaxWidth().height(190.dp)
            .background(Panel, RoundedCornerShape(22.dp))
            .border(1.dp, Color(0xFF34503A), RoundedCornerShape(22.dp))
            .padding(24.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("EXPERIENCIA PREMIUM", color = Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("TODO COMIENZA AQUÍ", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("Televisión • Deportes • Películas • Series", color = Muted, fontSize = 14.sp)
            Text("Selecciona una categoría para comenzar", color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ContentCard(section: Section, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.width(145.dp).height(112.dp)
            .background(if (focused) Color(0xFF263B29) else Panel, RoundedCornerShape(16.dp))
            .border(if (focused) 2.dp else 1.dp, if (focused) Neon else Color(0xFF263B29), RoundedCornerShape(16.dp))
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(section.icon, null, tint = Neon, modifier = Modifier.size(25.dp))
        Column {
            Text(section.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(section.description, color = Muted, fontSize = 9.sp, maxLines = 1)
        }
    }
}
